#include<stdio.h>

int main(void) {
	int u,d,c,n;
	u = 1;
	c = 3;
	d = 2;
	n = 100*c + 10*d + u; /* c vaut ", d vaut 2 et u vaut 1*/
	printf("321 = %i\n", n);
	return 0;	
}
	
