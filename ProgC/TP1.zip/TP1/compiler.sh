#!/bin/bash
echo "Compilation de l’exercice 1"
gcc -Wall -pedantic -ansi exercice1.c -o exercice1
echo "Compilation de l’exercice 2"
gcc -Wall -pedantic -ansi exercice2.c -o exercice2
echo "Compilation de l’exercice 3"
gcc -Wall -pedantic -ansi exercice2.c -o exercice3
