import numpy as np 
import matplotlib.pyplot as plt


"""========================================"""

def makeDTMF(N, freqStep, Fe, t, sig_s, sig_f): # t <=> sig_t

    sig_f = np.fft.fftshift(sig_f)      # middles the zero-point's axis
    sig_f = sig_f/N    # Normalization => ainsi le module ne dependra
                   
    freq = freqStep * np.arange(-N/2, N/2)  # ticks in frequency domain
    

    #=== Affichage console des valeurs des raies
    for i,r in enumerate(list(sig_f)):
        print("Raie {} \t= \t{:.5g}".format(freq[i],r))

    # plot signal DTMF-------------------------------------------
    plt.figure(figsize=(8,8))
    plt.subplots_adjust(hspace=.6) # espace entre les figures

    plt.subplot(3,1,1)
    plt.plot(t, sig_s, '.-', label="N={}, fe={}".format(N,Fe))
    plt.grid(True)
    plt.legend()
    plt.xlabel('Time (seconds)')
    plt.ylabel('Amplitude')
    plt.title('Signal DTMF')
    plt.axis('tight')

    # Plot spectral magnitude ------------------------------
    plt.subplot(3,1,2)
    plt.plot(freq, np.abs(sig_f), '.-b', label="freqStep={}".format(freqStep))
    plt.grid(True)
    plt.legend()
    plt.xlabel('Frequency')
    plt.ylabel('S(F) Magnitude (Linear)')   




    





"""========================================"""
if __name__ == '__main__':
    # lecture fichier phone.out
    sig_t, sig_s = np.loadtxt('phone.out')
    
    N = len(sig_t)
               
    Fe = 4000.       
    Te = 1./Fe       
    freqStep = Fe/N  
    f = 3*freqStep 




    

    
    # Calcul de la transformée de Fourier
    sig_f = np.fft.fft(sig_s) 
    






    makeDTMF(N, freqStep, Fe, sig_t, sig_s, sig_f) # affichage du signal DTMF

    plt.show()
"""
# Calcul de la puissance spectrale
    puissance_spectre = np.abs(sig_f)**2


    frequences_pic = np.where(puissance_spectre == np.max(puissance_spectre))[0]

    digits = []
    for pic in frequences_pic:
        digit = int(np.around(pic/N)*Fe)
        digits.append(digit)

    # Affichage du numéro de téléphone
    numero = "".join(digits)
    print(numero)
"""